<?php
$urlMap = [
     // Create a URL map here
];

$pathInfo = $_SERVER['PATH_INFO'] ?? '/';
if (isset($urlMap[$pathInfo])) {
    // Load a specific page script
    
} else {
    // Return a 404 status code
}