<?php

include(__DIR__ . '/../bootstrap.php');

// You shouldn't store passwords anywhere, but for testing purposes: these hashes are made of the same password: "test"
$users = [
    'matthias' => '$2y$10$1sXx3dPquOicIl53Y7XRdOqyS4P6flYXXpxHpTC83ZnusdxpEPtXe',
    'tomas' => '$2y$10$vruLMw5IRBI4WwGVfpwF2Om3VgULeTrd7yC3tHAURqVLaCW72unQy'
];

// implement the login functionality here

<?php
include(__DIR__ . '/../_footer.php');