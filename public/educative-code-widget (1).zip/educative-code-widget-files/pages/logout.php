<?php

include(__DIR__ . '/../bootstrap.php');

// implement the logout functionality here