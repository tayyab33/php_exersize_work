<?php
include(__DIR__ . '/../bootstrap.php');

// Add your code to create the tasks page

<?php
include(__DIR__ . '/../_footer.php');