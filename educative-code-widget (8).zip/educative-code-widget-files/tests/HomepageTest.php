<?php

use PHPUnit\Framework\TestCase;

final class HomepageTest extends TestCase
{
    /**
     * @test
     */
    public function phpunit_works(): void
    {
        self::assertTrue(true);
    }
}