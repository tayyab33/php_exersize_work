<?php

include(__DIR__ . '/../bootstrap.php');

$_SESSION = [];

header('Location: /login');
exit;