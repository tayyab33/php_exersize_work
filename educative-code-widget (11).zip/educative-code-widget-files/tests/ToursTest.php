<?php

use PHPUnit\Framework\TestCase;
use Symfony\Component\Panther\PantherTestCaseTrait;

final class ToursTest extends TestCase
{
    use PantherTestCaseTrait;

    /**
     * @test
     */
    public function create_a_new_tour(): void
    {
        $client = self::createHttpBrowserClient();

        $toursFile = __DIR__ . '/../data/tours.json';
        if (is_file($toursFile)) {
        unlink($toursFile);
        }

        $client->request('GET', self::$baseUri . '/create-tour');

        $client->submitForm(
            'Save',
            [
                'destination' => 'Berlin',
                'number_of_tickets_available' => 10,
                'is_accessible' => 'yes',
                'picture' => __DIR__ . '/berlin.jpg'
            ]
        );

        $response = $client->request('GET', '/list-tours');

        self::assertStringContainsString(
            'Berlin',
            $response->filter('td')->text()
        );
    }
}