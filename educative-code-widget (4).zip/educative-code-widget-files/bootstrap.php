<?php

set_exception_handler(function (Throwable $exception) {
    // Show the error page
});

session_start();