<?php

throw new RuntimeException('Something went wrong');