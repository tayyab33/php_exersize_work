<?php

include(__DIR__ . '/../bootstrap.php');

$title = 'Homepage';
include(__DIR__ . '/../_header.php');
?>
<h1>This is the homepage</h1>
<p><a href="/random">Get yourself a random number</a></p>
<?php
include(__DIR__ . '/../_footer.php');